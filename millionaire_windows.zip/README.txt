Who Wants to Be a Millionaire Game
----------------------------
1. Make sure all files remain in the same folder
2. Double-click millionaire.exe to start the game
3. Enjoy!

